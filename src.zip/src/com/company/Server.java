package com.company;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.lang.*;
public class Server {
    ServerSocket ss;
    Scanner scanner=new Scanner(System.in);
    private boolean shouldRun=true;
	private Spieler[] nutzerliste=new Spieler[100];
	private LinkedList<Spieler> nutzerarray=new LinkedList<>();
    ArrayList<ServerConnection> connections =new ArrayList<ServerConnection>();
    public Spieler[] getNutzerliste() {
        return nutzerliste;
    }

    public Server(){
        try{

            ss=new ServerSocket(4999);
            while(true){
                Socket s=ss.accept();
                ServerConnection sc=new ServerConnection (s, this);
                sc.start();
                connections.add(sc);
                //if (scanner.hasNextLine()) {
                  //  String line=scanner.nextLine();
                    //if (line.equals("KILL")) {
                      //  System.exit(0);
                    //}
               // }
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new Server();
    }
}
