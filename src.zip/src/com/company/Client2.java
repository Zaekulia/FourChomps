package com.company;

public class Client2 {
    public static void main (String[] args){
        new Client();
    }
}
