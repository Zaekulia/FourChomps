package com.company;

public class Spielzug {
    int zeile;
    int spalte;
    public Spielzug(int m, int n){
        zeile=m;
        spalte=n;
    }
}
